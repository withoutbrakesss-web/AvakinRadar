# AvakinRadar
Android prototype for monitoring the public Avakin Life official store.

**Current state:** UI prototype only. Store data extraction, change detection, scheduled background checks and notifications are not yet implemented. Do not treat the monitoring toggle as an active data service.

## Cloud build
Build debug APK with Android SDK/Gradle using GitHub Actions. See `BUILD_ON_GITHUB_MOBILE.md` for the mobile-friendly upload workflow.
