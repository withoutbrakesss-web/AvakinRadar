# Build APK through GitHub Actions (phone-friendly)

1. Upload this entire project folder's files to your repository (GitHub's upload page may not support folder upload on mobile; the included project ZIP is meant for a workflow extraction approach).
2. If uploading only `AvakinRadar_project_bundle.zip`, create a workflow file at `.github/workflows/android-build.yml` using the companion workflow text supplied separately.
3. Run the workflow from Actions, then download the `AvakinRadar-debug-apk` artifact and install the APK on your Android phone.

This project is an early UI prototype. Monitoring and notifications are not active yet.
