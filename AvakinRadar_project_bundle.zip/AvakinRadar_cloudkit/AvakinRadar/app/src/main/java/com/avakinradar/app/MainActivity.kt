package com.avakinradar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RadarApp() }
    }
}

private val Ink = Color(0xFF101020)
private val Violet = Color(0xFF8A5CFF)
private val Blue = Color(0xFF4D9CFF)
private val CardColor = Color(0xFF1C1B32)

@Composable
fun RadarApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var monitorOn by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Blue, background = Ink, surface = CardColor)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = CardColor) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Radar, null) }, label = { Text("Обзор") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("История") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Header()
                when (selectedTab) {
                    0 -> Overview(monitorOn, { monitorOn = it })
                    1 -> History()
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text("AVAKIN", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
        Text("RADAR", color = Violet, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
        Text("Следим за официальным магазином", color = Color.LightGray)
    }
}

@Composable
private fun Overview(enabled: Boolean, onToggle: (Boolean) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CardColor), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = Violet, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp)); Text("Мониторинг магазина", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(if (enabled) "Мониторинг включён" else "Мониторинг выключен", color = if (enabled) Color(0xFF71E6B0) else Color.LightGray)
                    Text("Подключение к источнику ещё не настроено", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onToggle(!enabled) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                        Text(if (enabled) "Остановить" else "Включить мониторинг")
                    }
                }
            }
        }
        item { Text("Категории", color = Color.White, fontWeight = FontWeight.Bold) }
        items(listOf("Короны / Crown-пакеты" to "Отслеживание предложений с Crown", "Avacoins" to "Монеты и бонусы", "Скидки и акции" to "Временные и ограниченные предложения")) { (title, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = CardColor), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, null, tint = Blue)
                    Spacer(Modifier.width(12.dp)); Column { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(desc, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item {
            Text("Важно: пока это ранний интерфейс. Реальное получение данных магазина, сравнение снимков и push-уведомления ещё предстоит подключить.", color = Color(0xFFFFCC80), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun History() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("История изменений", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) { Text("Пока нет записей. История появится после подключения мониторинга.", Modifier.padding(16.dp), color = Color.LightGray) }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Настройки", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) {
            Column(Modifier.padding(16.dp)) {
                Text("Источник", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Официальный магазин Avakin Life", color = Color.LightGray)
                Text("https://store.avakin.com/", color = Blue)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) { Text("Версия приложения: 0.1.0 — прототип интерфейса", Modifier.padding(16.dp), color = Color.LightGray) }
    }
}
